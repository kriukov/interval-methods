include("NewtonMethod.jl")
f(x) = sin(x)
newton(f, Interval(-20., 20.), 40)